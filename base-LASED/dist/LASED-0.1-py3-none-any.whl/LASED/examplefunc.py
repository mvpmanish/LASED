def example_func():
    print("Hello World!")